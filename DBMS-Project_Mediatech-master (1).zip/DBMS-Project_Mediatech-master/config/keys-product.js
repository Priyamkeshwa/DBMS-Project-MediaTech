module.exports={
    MongoURI: process.env.MONGO_URI,
    GoogleClientID: process.env.GOOGLE_CLIENT_ID,
    GoogleClientSecret: process.env.GOOGLE_CLIENT_SECRET,
    FacebookClientID: process.env.FACEBOOK_CLIENT_ID,
    FacebookClientSecret: process.env.FACEBOOK_CLIENT_SECRET,
    LinkedINClientID: process.env.LINKEDIN_CLIENT_ID,
    LinkedINClientSecret: process.env.LINKEDIN_CLIENT_SECRET
}

